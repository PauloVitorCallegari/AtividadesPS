package view;

import java.util.Scanner;

public class CalculatorView {
    private Scanner scanner;

    public CalculatorView() {
        scanner = new Scanner(System.in);
    }

    public int getNumber(String prompt) {
        System.out.print(prompt);
        return scanner.nextInt();
    }

    public String getOperation() {
        System.out.println("\nEscolha a operação:");
        System.out.println("1 - Adição (+)");
        System.out.println("2 - Subtração (-)");
        System.out.println("3 - Multiplicação (*)");
        System.out.println("4 - Divisão (/)");
        System.out.print("Opção: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1: return "+";
            case 2: return "-";
            case 3: return "*";
            case 4: return "/";
            default: return "";
        }
    }

    public int[] getNumbers() {
        int num1 = getNumber("Digite o primeiro número: ");
        int num2 = getNumber("Digite o segundo número: ");
        return new int[]{num1, num2};
    }

    public void showResult(String result) {
        System.out.println("Resultado: " + result);
    }

    public void showError(String message) {
        System.out.println("Erro: " + message);
    }
}
