package controller;

import model.CalculatorModel;
import view.CalculatorView;

public class CalculatorController {
    private CalculatorModel model;
    private CalculatorView view;

    public CalculatorController(CalculatorModel model, CalculatorView view) {
        this.model = model;
        this.view = view;
    }

    public void run() {
        int[] numbers = view.getNumbers();
        String operation = view.getOperation();

        try {
            switch (operation) {
                case "+":
                    view.showResult(String.valueOf(model.add(numbers[0], numbers[1])));
                    break;
                case "-":
                    view.showResult(String.valueOf(model.subtract(numbers[0], numbers[1])));
                    break;
                case "*":
                    view.showResult(String.valueOf(model.multiply(numbers[0], numbers[1])));
                    break;
                case "/":
                    view.showResult(String.valueOf(model.divide(numbers[0], numbers[1])));
                    break;
                default:
                    view.showError("Operação inválida");
            }
        } catch (Exception e) {
            view.showError(e.getMessage());
        }
    }
}
