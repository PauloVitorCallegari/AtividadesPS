import controller.CalculadoraController;
import view.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        CalculadoraController controller = new CalculadoraController(menu);

        controller.calcular();

        menu.fecharScanner();
    }
}