package controller;

import model.Operacao;
import view.Menu;

import java.lang.reflect.Constructor;

public class CalculadoraController {
    private final Menu menu;
    private static final String[] OPERACOES = {"Soma", "Subtracao", "Multiplicacao", "Divisao"};

    public CalculadoraController(Menu menu) {
        this.menu = menu;
    }

    public void calcular() {
        int opcao = menu.show();

        if (opcao == 5) {
            menu.exibirMensagem("Saindo...");
            return;
        }

        if (opcao < 1 || opcao > 4) {
            menu.exibirMensagem("Opção inválida!");
            return;
        }

        double[] valores = menu.capturarValores();
        double num1 = valores[0];
        double num2 = valores[1];

        try {
            String className = "model." + OPERACOES[opcao - 1];
            Class<?> clazz = Class.forName(className);
            Constructor<?> constructor = clazz.getDeclaredConstructor();
            Operacao operacao = (Operacao) constructor.newInstance();

            double resultado = operacao.calcular(num1, num2);
            menu.exibirResultado(resultado);
        } catch (Exception e) {
            menu.exibirMensagem("Erro: " + e.getMessage());
        }
    }
}

