package model;

public class Multiplicacao implements Operacao {
    public double calcular(double a, double b) {
        return a * b;
    }
}
