package model;

public class Subtracao implements Operacao {
    public double calcular(double a, double b) {
        return a - b;
    }
}
