package model;

public interface Operacao {
    double calcular(double a, double b);
}
