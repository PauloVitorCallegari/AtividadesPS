package view;

import java.util.Scanner;

public class Menu {
    private final Scanner scanner;

    public Menu() {
        this.scanner = new Scanner(System.in);
    }

    public int show() {
        this.showMenu();
        return scanner.nextInt();
    }

    private void showMenu() {
        System.out.println("---->Olá Meu fi!<----");
        System.out.println("Escolha uma das opções:");
        System.out.println("1 - Somar");
        System.out.println("2 - Subtrair");
        System.out.println("3 - Multiplicar");
        System.out.println("4 - Dividir");
        System.out.println("5 - Vá embora ...");
    }

    public double[] capturarValores() {
        System.out.println("Informe o primeiro valor:");
        double valor1 = scanner.nextDouble();
        System.out.println("Informe o segundo valor:");
        double valor2 = scanner.nextDouble();
        return new double[]{valor1, valor2};
    }

    public void exibirResultado(double resultado) {
        System.out.println("Resultado: " + resultado);
    }

    public void exibirMensagem(String mensagem) {
        System.out.println(mensagem);
    }

    public void fecharScanner() {
        scanner.close();
    }
}
